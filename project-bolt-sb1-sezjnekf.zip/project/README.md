# Project Nexus

An AI-powered campus super-app that integrates major aspects of student life into one intelligent, unified ecosystem.

## Overview

Project Nexus is a comprehensive full-stack application designed to enhance the student experience by bringing together essential campus services, academic tools, marketplace features, and AI-powered insights in a single platform.

## Features

### 1. Daily Pulse
Real-time campus information hub featuring:
- **Live Mess Menu**: Daily meals with nutritional info, allergen warnings, and crowd predictions
- **AI Mail Summarizer**: Parse lengthy college emails into actionable one-line summaries with automatic categorization (academic, events, urgent), priority scoring, and deadline extraction
- **Campus Announcements**: Stay updated with important campus-wide notifications

### 2. Student Exchange
Campus marketplace and collaboration platform including:
- **Marketplace**: Buy/sell books, electronics, furniture with smart price recommendations
- **Lost & Found**: Report lost/found items with AI object recognition and tag matching
- **Travel Sharing**: Find cab-pool partners with route optimization and cost splitting

### 3. Academic Cockpit
Student command center featuring:
- **Live Timetable**: Class schedules with smart reminders and room changes
- **AI Study Recommendations**: Intelligent study planning based on your schedule
- **Upcoming Class Alerts**: Never miss a class with real-time notifications

### 4. Explorer's Guide
Smart campus discovery system with:
- **Nearby Hub**: Discover local eateries and attractions with AI recommendations
- **Vibe Tags**: Filter places by study, budget, hangout preferences
- **Campus Navigation**: Interactive map with building and room finder

## AI Features

Project Nexus includes multiple AI-powered capabilities:

1. **Email Summarization (NLP)**
   - Converts long emails into actionable summaries
   - Automatic categorization and priority scoring
   - Deadline extraction and parsing

2. **Smart Recommendations**
   - Study planner based on academic schedule
   - Restaurant and location recommendations
   - Crowd prediction for mess timings

3. **AI Tagging**
   - Automatic tag generation for lost & found items
   - Object recognition from descriptions

## Technology Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS with dark mode support
- **Backend**: Supabase (PostgreSQL + Authentication + Real-time)
- **Icons**: Lucide React
- **Deployment**: Ready for GitHub Pages or Vercel

## Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd project-nexus
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment variables**
   The `.env` file contains Supabase configuration (already set up)

4. **Run the development server**
   ```bash
   npm run dev
   ```

5. **Build for production**
   ```bash
   npm run build
   ```

## Demo Credentials

For testing the application, you can either:

1. **Create a new account** using the signup form
2. **Use demo account**:
   - Email: student@nexus.edu
   - Password: password

## Database Schema

The application uses a comprehensive PostgreSQL schema with the following tables:

- `profiles`: Extended user information with role-based access
- `mess_menu`: Daily mess menu with nutritional data
- `campus_emails`: AI-summarized emails with priority scoring
- `marketplace_items`: Student marketplace listings
- `lost_found_items`: Lost and found reports with AI tags
- `timetables`: Academic schedules
- `announcements`: Campus-wide announcements
- `travel_shares`: Cab pooling and travel coordination

All tables include Row Level Security (RLS) policies for data protection.

## Key Features Implementation

### Authentication
- Secure email/password authentication via Supabase
- Role-based access control (Student, Faculty, Admin)
- Protected routes and personalized experiences

### Real-time Updates
- Live data synchronization across all modules
- Instant notifications for important events
- Real-time marketplace and lost & found updates

### Responsive Design
- Mobile-first approach
- Tablet and desktop optimized layouts
- Touch-friendly interface elements

### Dark Mode
- System-wide dark mode toggle
- Persistent theme preference
- Optimized contrast ratios for accessibility

## Architecture

Project Nexus follows a modular architecture:

```
src/
├── components/
│   ├── Auth.tsx              # Authentication UI
│   ├── Dashboard.tsx         # Main dashboard layout
│   └── modules/
│       ├── DailyPulse.tsx    # Daily pulse module
│       ├── StudentExchange.tsx # Marketplace module
│       ├── AcademicCockpit.tsx # Academic tools
│       └── ExplorerGuide.tsx   # Campus exploration
├── contexts/
│   └── AuthContext.tsx       # Authentication state
├── lib/
│   └── supabase.ts          # Supabase client & types
└── App.tsx                   # Root component
```

## Design Philosophy

Project Nexus is built as an **integrated ecosystem** rather than isolated features:

- **AI-First**: Reduce user effort through intelligent automation
- **Unified Experience**: Single platform for all campus needs
- **Student-Centric**: Designed with student workflows in mind
- **Privacy-Focused**: Row-level security on all sensitive data
- **Scalable**: Modular architecture for easy expansion

## Security

- All database tables use Row Level Security (RLS)
- Authentication via Supabase Auth
- Secure API endpoints
- Input validation and sanitization
- No hardcoded secrets or API keys

## Future Enhancements

Potential additions for future versions:
- Push notifications
- Social networking features
- Integration with official college systems
- Advanced analytics dashboard
- Mobile app (React Native)
- Real-time chat and messaging

## Contributing

This project is designed as a campus super-app prototype. Contributions, issues, and feature requests are welcome.

## License

This project is available for educational and demonstration purposes.

## Acknowledgments

Built with modern web technologies and powered by AI to create a seamless campus experience.

---

**Project Nexus** - Connecting campus life through intelligent integration.
