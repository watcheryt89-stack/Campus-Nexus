/*
  # Project Nexus - Campus Super App Database Schema

  ## Overview
  Complete database schema for an AI-powered campus super-app integrating
  student life aspects: daily pulse, marketplace, academics, and social features.

  ## New Tables Created

  ### 1. profiles
  Extended user profile information beyond auth.users
  - `id` (uuid, references auth.users)
  - `full_name` (text)
  - `role` (text: student, faculty, admin)
  - `department` (text)
  - `year` (integer)
  - `avatar_url` (text)
  - `created_at` (timestamptz)

  ### 2. mess_menu
  Daily mess menu with nutritional info
  - `id` (uuid, primary key)
  - `date` (date)
  - `meal_type` (text: breakfast, lunch, dinner, snacks)
  - `items` (jsonb array of menu items)
  - `nutritional_info` (jsonb)
  - `allergens` (text array)
  - `crowd_prediction` (integer 1-5)
  - `created_at` (timestamptz)

  ### 3. campus_emails
  Parsed campus emails with AI summaries
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `subject` (text)
  - `original_content` (text)
  - `ai_summary` (text)
  - `category` (text: academic, events, urgent, general)
  - `priority_score` (integer 1-5)
  - `deadlines` (jsonb array)
  - `is_read` (boolean)
  - `received_at` (timestamptz)

  ### 4. marketplace_items
  Student marketplace for buying/selling
  - `id` (uuid, primary key)
  - `seller_id` (uuid, references profiles)
  - `title` (text)
  - `description` (text)
  - `category` (text)
  - `price` (numeric)
  - `images` (text array)
  - `status` (text: available, sold, reserved)
  - `views` (integer)
  - `created_at` (timestamptz)

  ### 5. lost_found_items
  Lost and found with AI object recognition
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `type` (text: lost, found)
  - `item_name` (text)
  - `description` (text)
  - `category` (text)
  - `location` (text)
  - `image_url` (text)
  - `ai_tags` (text array)
  - `status` (text: active, resolved)
  - `contact_info` (text)
  - `created_at` (timestamptz)

  ### 6. timetables
  Academic timetable entries
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `course_code` (text)
  - `course_name` (text)
  - `day_of_week` (integer 0-6)
  - `start_time` (time)
  - `end_time` (time)
  - `room` (text)
  - `instructor` (text)
  - `created_at` (timestamptz)

  ### 7. announcements
  Campus-wide announcements
  - `id` (uuid, primary key)
  - `title` (text)
  - `content` (text)
  - `category` (text)
  - `priority` (integer)
  - `posted_by` (uuid, references profiles)
  - `created_at` (timestamptz)

  ### 8. travel_shares
  Cab pooling and travel sharing
  - `id` (uuid, primary key)
  - `creator_id` (uuid, references profiles)
  - `from_location` (text)
  - `to_location` (text)
  - `departure_time` (timestamptz)
  - `seats_available` (integer)
  - `estimated_cost` (numeric)
  - `status` (text: open, full, completed)
  - `created_at` (timestamptz)

  ## Security
  Row Level Security (RLS) enabled on all tables with appropriate policies
  for authenticated users based on ownership and role-based access.
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles table (extends auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  role text NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'faculty', 'admin')),
  department text,
  year integer,
  avatar_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Mess menu table
CREATE TABLE IF NOT EXISTS mess_menu (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  date date NOT NULL,
  meal_type text NOT NULL CHECK (meal_type IN ('breakfast', 'lunch', 'dinner', 'snacks')),
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  nutritional_info jsonb DEFAULT '{}'::jsonb,
  allergens text[] DEFAULT ARRAY[]::text[],
  crowd_prediction integer DEFAULT 3 CHECK (crowd_prediction BETWEEN 1 AND 5),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE mess_menu ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view mess menu"
  ON mess_menu FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage mess menu"
  ON mess_menu FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Campus emails table
CREATE TABLE IF NOT EXISTS campus_emails (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  subject text NOT NULL,
  original_content text NOT NULL,
  ai_summary text,
  category text DEFAULT 'general' CHECK (category IN ('academic', 'events', 'urgent', 'general')),
  priority_score integer DEFAULT 3 CHECK (priority_score BETWEEN 1 AND 5),
  deadlines jsonb DEFAULT '[]'::jsonb,
  is_read boolean DEFAULT false,
  received_at timestamptz DEFAULT now()
);

ALTER TABLE campus_emails ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own emails"
  ON campus_emails FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own emails"
  ON campus_emails FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own emails"
  ON campus_emails FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Marketplace items table
CREATE TABLE IF NOT EXISTS marketplace_items (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  seller_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  category text NOT NULL,
  price numeric(10, 2) NOT NULL,
  images text[] DEFAULT ARRAY[]::text[],
  status text DEFAULT 'available' CHECK (status IN ('available', 'sold', 'reserved')),
  views integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE marketplace_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view available marketplace items"
  ON marketplace_items FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Sellers can insert own items"
  ON marketplace_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Sellers can update own items"
  ON marketplace_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = seller_id)
  WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Sellers can delete own items"
  ON marketplace_items FOR DELETE
  TO authenticated
  USING (auth.uid() = seller_id);

-- Lost and found items table
CREATE TABLE IF NOT EXISTS lost_found_items (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('lost', 'found')),
  item_name text NOT NULL,
  description text,
  category text,
  location text,
  image_url text,
  ai_tags text[] DEFAULT ARRAY[]::text[],
  status text DEFAULT 'active' CHECK (status IN ('active', 'resolved')),
  contact_info text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE lost_found_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active lost/found items"
  ON lost_found_items FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own lost/found items"
  ON lost_found_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own lost/found items"
  ON lost_found_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Timetables table
CREATE TABLE IF NOT EXISTS timetables (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  course_code text NOT NULL,
  course_name text NOT NULL,
  day_of_week integer NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  start_time time NOT NULL,
  end_time time NOT NULL,
  room text,
  instructor text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE timetables ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own timetable"
  ON timetables FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage own timetable"
  ON timetables FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Announcements table
CREATE TABLE IF NOT EXISTS announcements (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  content text NOT NULL,
  category text DEFAULT 'general',
  priority integer DEFAULT 3 CHECK (priority BETWEEN 1 AND 5),
  posted_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view announcements"
  ON announcements FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Faculty and admins can post announcements"
  ON announcements FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('faculty', 'admin')
    )
  );

-- Travel shares table
CREATE TABLE IF NOT EXISTS travel_shares (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  creator_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  from_location text NOT NULL,
  to_location text NOT NULL,
  departure_time timestamptz NOT NULL,
  seats_available integer NOT NULL,
  estimated_cost numeric(10, 2),
  status text DEFAULT 'open' CHECK (status IN ('open', 'full', 'completed', 'cancelled')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE travel_shares ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view open travel shares"
  ON travel_shares FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create travel shares"
  ON travel_shares FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = creator_id);

CREATE POLICY "Creators can update own travel shares"
  ON travel_shares FOR UPDATE
  TO authenticated
  USING (auth.uid() = creator_id)
  WITH CHECK (auth.uid() = creator_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_mess_menu_date ON mess_menu(date);
CREATE INDEX IF NOT EXISTS idx_campus_emails_user ON campus_emails(user_id);
CREATE INDEX IF NOT EXISTS idx_marketplace_status ON marketplace_items(status);
CREATE INDEX IF NOT EXISTS idx_lost_found_status ON lost_found_items(status);
CREATE INDEX IF NOT EXISTS idx_timetables_user ON timetables(user_id);
CREATE INDEX IF NOT EXISTS idx_travel_shares_status ON travel_shares(status);