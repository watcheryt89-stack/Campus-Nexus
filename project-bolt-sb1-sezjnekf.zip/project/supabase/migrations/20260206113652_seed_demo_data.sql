/*
  # Seed Demo Data for Project Nexus

  ## Purpose
  Populate the database with sample data for demonstration and testing purposes.

  ## Data Added
  1. Demo mess menu items for today
  2. Sample announcements
  3. Demo marketplace items
  4. Sample lost and found items
  5. Demo travel shares

  ## Notes
  - This migration is idempotent and can be run multiple times
  - Data is for testing purposes only
*/

-- Insert demo mess menu for today
DO $$
DECLARE
  today_date date := CURRENT_DATE;
BEGIN
  -- Delete existing menu for today to avoid duplicates
  DELETE FROM mess_menu WHERE date = today_date;

  INSERT INTO mess_menu (date, meal_type, items, nutritional_info, allergens, crowd_prediction)
  VALUES
    (today_date, 'breakfast', 
     '[{"name": "Idli Sambar"}, {"name": "Dosa"}, {"name": "Poha"}, {"name": "Toast & Jam"}, {"name": "Fresh Fruits"}, {"name": "Coffee/Tea"}]'::jsonb,
     '{"calories": 350, "protein": "12g", "carbs": "65g"}'::jsonb,
     ARRAY['gluten']::text[],
     3),
    
    (today_date, 'lunch',
     '[{"name": "Rice"}, {"name": "Dal Tadka"}, {"name": "Paneer Curry"}, {"name": "Mixed Veg"}, {"name": "Roti"}, {"name": "Salad"}, {"name": "Curd"}]'::jsonb,
     '{"calories": 650, "protein": "22g", "carbs": "95g"}'::jsonb,
     ARRAY['dairy']::text[],
     5),
    
    (today_date, 'snacks',
     '[{"name": "Samosa"}, {"name": "Pakora"}, {"name": "Chai"}, {"name": "Biscuits"}]'::jsonb,
     '{"calories": 250, "protein": "6g", "carbs": "38g"}'::jsonb,
     ARRAY['gluten']::text[],
     2),
    
    (today_date, 'dinner',
     '[{"name": "Fried Rice"}, {"name": "Manchurian"}, {"name": "Noodles"}, {"name": "Soup"}, {"name": "Ice Cream"}]'::jsonb,
     '{"calories": 700, "protein": "18g", "carbs": "88g"}'::jsonb,
     ARRAY['soy', 'gluten']::text[],
     4);
END $$;

-- Insert demo announcements
INSERT INTO announcements (title, content, category, priority)
VALUES
  ('Mid-term Exams Schedule Released', 'Mid-term examinations will commence from next Monday. Check the academic portal for your personalized schedule. Best of luck!', 'academic', 5),
  ('Tech Fest 2024 - Register Now', 'Annual tech fest registration is now open. Participate in coding competitions, hackathons, and workshops. Prizes worth $10,000!', 'events', 4),
  ('Library Hours Extended', 'Due to upcoming exams, the library will be open 24/7 for the next two weeks. Additional study spaces available.', 'general', 3),
  ('Guest Lecture on AI/ML', 'Dr. Sarah Johnson from MIT will deliver a guest lecture on "Future of Artificial Intelligence" on Friday at 4 PM in Auditorium A.', 'events', 4),
  ('Campus WiFi Maintenance', 'WiFi services will be temporarily unavailable on Saturday from 2 AM to 6 AM due to scheduled maintenance.', 'urgent', 3)
ON CONFLICT DO NOTHING;

-- Note: We cannot insert demo marketplace items, lost/found items, or travel shares
-- because they require user_id references. These should be created by actual users
-- through the application interface after they sign up.

-- Insert a helpful reminder comment
COMMENT ON TABLE mess_menu IS 'Contains daily mess menu with nutritional info and crowd predictions';
COMMENT ON TABLE campus_emails IS 'AI-summarized campus emails with priority scoring and deadline extraction';
COMMENT ON TABLE marketplace_items IS 'Student marketplace for buying/selling items';
COMMENT ON TABLE lost_found_items IS 'Lost and found items with AI tagging';
COMMENT ON TABLE timetables IS 'Student academic timetables';
