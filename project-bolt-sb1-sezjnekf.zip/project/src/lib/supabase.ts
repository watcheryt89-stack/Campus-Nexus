import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  full_name: string;
  role: 'student' | 'faculty' | 'admin';
  department: string | null;
  year: number | null;
  avatar_url: string | null;
  created_at: string;
};

export type MessMenuItem = {
  id: string;
  date: string;
  meal_type: 'breakfast' | 'lunch' | 'dinner' | 'snacks';
  items: any[];
  nutritional_info: any;
  allergens: string[];
  crowd_prediction: number;
  created_at: string;
};

export type CampusEmail = {
  id: string;
  user_id: string;
  subject: string;
  original_content: string;
  ai_summary: string | null;
  category: 'academic' | 'events' | 'urgent' | 'general';
  priority_score: number;
  deadlines: any[];
  is_read: boolean;
  received_at: string;
};

export type MarketplaceItem = {
  id: string;
  seller_id: string;
  title: string;
  description: string | null;
  category: string;
  price: number;
  images: string[];
  status: 'available' | 'sold' | 'reserved';
  views: number;
  created_at: string;
  profiles?: Profile;
};

export type LostFoundItem = {
  id: string;
  user_id: string;
  type: 'lost' | 'found';
  item_name: string;
  description: string | null;
  category: string | null;
  location: string | null;
  image_url: string | null;
  ai_tags: string[];
  status: 'active' | 'resolved';
  contact_info: string | null;
  created_at: string;
  profiles?: Profile;
};

export type Timetable = {
  id: string;
  user_id: string;
  course_code: string;
  course_name: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  room: string | null;
  instructor: string | null;
  created_at: string;
};

export type Announcement = {
  id: string;
  title: string;
  content: string;
  category: string;
  priority: number;
  posted_by: string | null;
  created_at: string;
};

export type TravelShare = {
  id: string;
  creator_id: string;
  from_location: string;
  to_location: string;
  departure_time: string;
  seats_available: number;
  estimated_cost: number | null;
  status: 'open' | 'full' | 'completed' | 'cancelled';
  created_at: string;
  profiles?: Profile;
};
