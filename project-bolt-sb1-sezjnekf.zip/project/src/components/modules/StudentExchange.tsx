import { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase, MarketplaceItem, LostFoundItem, TravelShare } from '../../lib/supabase';
import {
  ShoppingBag, Search, AlertCircle, Car, Plus, X, DollarSign,
  MapPin, Clock, Users, Tag
} from 'lucide-react';

export default function StudentExchange() {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'marketplace' | 'lostfound' | 'travel'>('marketplace');
  const [marketplaceItems, setMarketplaceItems] = useState<MarketplaceItem[]>([]);
  const [lostFoundItems, setLostFoundItems] = useState<LostFoundItem[]>([]);
  const [travelShares, setTravelShares] = useState<TravelShare[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadData();
  }, [activeTab]);

  async function loadData() {
    setLoading(true);
    try {
      if (activeTab === 'marketplace') {
        const { data } = await supabase
          .from('marketplace_items')
          .select('*, profiles(full_name)')
          .eq('status', 'available')
          .order('created_at', { ascending: false });
        setMarketplaceItems(data || []);
      } else if (activeTab === 'lostfound') {
        const { data } = await supabase
          .from('lost_found_items')
          .select('*, profiles(full_name)')
          .eq('status', 'active')
          .order('created_at', { ascending: false });
        setLostFoundItems(data || []);
      } else if (activeTab === 'travel') {
        const { data } = await supabase
          .from('travel_shares')
          .select('*, profiles(full_name)')
          .in('status', ['open', 'full'])
          .order('departure_time', { ascending: true });
        setTravelShares(data || []);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }

  const filteredMarketplace = marketplaceItems.filter(item =>
    item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredLostFound = lostFoundItems.filter(item =>
    item.item_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (item.location && item.location.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const filteredTravel = travelShares.filter(item =>
    item.from_location.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.to_location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Student Exchange</h2>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add New
        </button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
        />
      </div>

      <div className="flex gap-2 border-b border-gray-200 dark:border-gray-700">
        <button
          onClick={() => setActiveTab('marketplace')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'marketplace'
              ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-4 h-4" />
            Marketplace ({marketplaceItems.length})
          </div>
        </button>
        <button
          onClick={() => setActiveTab('lostfound')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'lostfound'
              ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            Lost & Found ({lostFoundItems.length})
          </div>
        </button>
        <button
          onClick={() => setActiveTab('travel')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'travel'
              ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          <div className="flex items-center gap-2">
            <Car className="w-4 h-4" />
            Travel Sharing ({travelShares.length})
          </div>
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <>
          {activeTab === 'marketplace' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredMarketplace.length === 0 ? (
                <div className="col-span-full text-center py-12">
                  <ShoppingBag className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">No items available</p>
                </div>
              ) : (
                filteredMarketplace.map((item) => (
                  <div key={item.id} className="border border-gray-200 dark:border-gray-700 rounded-xl p-4 hover:shadow-lg transition-shadow">
                    <div className="aspect-video bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 rounded-lg mb-3 flex items-center justify-center">
                      <ShoppingBag className="w-12 h-12 text-gray-400" />
                    </div>
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-gray-900 dark:text-white">{item.title}</h3>
                      <span className="text-lg font-bold text-green-600 dark:text-green-400">
                        ${item.price}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">
                      {item.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Tag className="w-4 h-4 text-gray-500" />
                        <span className="text-xs text-gray-600 dark:text-gray-400">{item.category}</span>
                      </div>
                      <span className="text-xs text-gray-500">
                        by {item.profiles?.full_name || 'Unknown'}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'lostfound' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredLostFound.length === 0 ? (
                <div className="col-span-full text-center py-12">
                  <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">No items reported</p>
                </div>
              ) : (
                filteredLostFound.map((item) => (
                  <div
                    key={item.id}
                    className={`border-2 rounded-xl p-4 ${
                      item.type === 'lost'
                        ? 'border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-900/10'
                        : 'border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/10'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <span
                          className={`text-xs px-2 py-1 rounded-full font-medium ${
                            item.type === 'lost'
                              ? 'bg-red-200 text-red-700 dark:bg-red-900 dark:text-red-300'
                              : 'bg-green-200 text-green-700 dark:bg-green-900 dark:text-green-300'
                          }`}
                        >
                          {item.type.toUpperCase()}
                        </span>
                      </div>
                      <span className="text-xs text-gray-500">
                        {new Date(item.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-2">{item.item_name}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{item.description}</p>
                    {item.location && (
                      <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 mb-2">
                        <MapPin className="w-4 h-4" />
                        <span>{item.location}</span>
                      </div>
                    )}
                    {item.ai_tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {item.ai_tags.map((tag, idx) => (
                          <span key={idx} className="text-xs px-2 py-1 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                    <div className="text-xs text-gray-600 dark:text-gray-400">
                      Contact: {item.contact_info || item.profiles?.full_name || 'See admin'}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'travel' && (
            <div className="space-y-4">
              {filteredTravel.length === 0 ? (
                <div className="text-center py-12">
                  <Car className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">No travel shares available</p>
                </div>
              ) : (
                filteredTravel.map((travel) => (
                  <div key={travel.id} className="border border-gray-200 dark:border-gray-700 rounded-xl p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-5 h-5 text-blue-500" />
                            <span className="font-semibold text-gray-900 dark:text-white">{travel.from_location}</span>
                          </div>
                          <span className="text-gray-400">→</span>
                          <div className="flex items-center gap-2">
                            <MapPin className="w-5 h-5 text-green-500" />
                            <span className="font-semibold text-gray-900 dark:text-white">{travel.to_location}</span>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-400">
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4" />
                            <span>{new Date(travel.departure_time).toLocaleString()}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Users className="w-4 h-4" />
                            <span>{travel.seats_available} seats</span>
                          </div>
                          {travel.estimated_cost && (
                            <div className="flex items-center gap-2">
                              <DollarSign className="w-4 h-4" />
                              <span>${travel.estimated_cost} per person</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          travel.status === 'open'
                            ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300'
                            : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300'
                        }`}
                      >
                        {travel.status}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      Posted by {travel.profiles?.full_name || 'Unknown'}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </>
      )}

      {showAddModal && (
        <AddItemModal
          activeTab={activeTab}
          onClose={() => setShowAddModal(false)}
          onSuccess={() => {
            setShowAddModal(false);
            loadData();
          }}
          userId={profile?.id || ''}
        />
      )}
    </div>
  );
}

function AddItemModal({
  activeTab,
  onClose,
  onSuccess,
  userId,
}: {
  activeTab: 'marketplace' | 'lostfound' | 'travel';
  onClose: () => void;
  onSuccess: () => void;
  userId: string;
}) {
  const [formData, setFormData] = useState<any>({});
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    try {
      if (activeTab === 'marketplace') {
        await supabase.from('marketplace_items').insert({
          seller_id: userId,
          title: formData.title,
          description: formData.description,
          category: formData.category || 'other',
          price: parseFloat(formData.price),
          status: 'available',
        });
      } else if (activeTab === 'lostfound') {
        await supabase.from('lost_found_items').insert({
          user_id: userId,
          type: formData.type,
          item_name: formData.item_name,
          description: formData.description,
          location: formData.location,
          category: formData.category,
          contact_info: formData.contact_info,
          ai_tags: formData.item_name.toLowerCase().split(' '),
          status: 'active',
        });
      } else if (activeTab === 'travel') {
        await supabase.from('travel_shares').insert({
          creator_id: userId,
          from_location: formData.from_location,
          to_location: formData.to_location,
          departure_time: formData.departure_time,
          seats_available: parseInt(formData.seats_available),
          estimated_cost: formData.estimated_cost ? parseFloat(formData.estimated_cost) : null,
          status: 'open',
        });
      }
      onSuccess();
    } catch (error) {
      console.error('Error adding item:', error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white">
            Add {activeTab === 'marketplace' ? 'Item' : activeTab === 'lostfound' ? 'Lost/Found Item' : 'Travel Share'}
          </h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {activeTab === 'marketplace' && (
            <>
              <input
                type="text"
                placeholder="Item title"
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                required
              />
              <textarea
                placeholder="Description"
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white h-24"
                required
              />
              <input
                type="text"
                placeholder="Category (books, electronics, etc.)"
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                required
              />
              <input
                type="number"
                step="0.01"
                placeholder="Price"
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                required
              />
            </>
          )}

          {activeTab === 'lostfound' && (
            <>
              <select
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                required
              >
                <option value="">Select type</option>
                <option value="lost">Lost</option>
                <option value="found">Found</option>
              </select>
              <input
                type="text"
                placeholder="Item name"
                onChange={(e) => setFormData({ ...formData, item_name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                required
              />
              <textarea
                placeholder="Description"
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white h-24"
              />
              <input
                type="text"
                placeholder="Location"
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
              />
              <input
                type="text"
                placeholder="Contact info"
                onChange={(e) => setFormData({ ...formData, contact_info: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
              />
            </>
          )}

          {activeTab === 'travel' && (
            <>
              <input
                type="text"
                placeholder="From location"
                onChange={(e) => setFormData({ ...formData, from_location: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                required
              />
              <input
                type="text"
                placeholder="To location"
                onChange={(e) => setFormData({ ...formData, to_location: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                required
              />
              <input
                type="datetime-local"
                onChange={(e) => setFormData({ ...formData, departure_time: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                required
              />
              <input
                type="number"
                placeholder="Available seats"
                onChange={(e) => setFormData({ ...formData, seats_available: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                required
              />
              <input
                type="number"
                step="0.01"
                placeholder="Estimated cost per person (optional)"
                onChange={(e) => setFormData({ ...formData, estimated_cost: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
              />
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 rounded-lg transition-colors disabled:opacity-50"
          >
            {loading ? 'Adding...' : 'Add Item'}
          </button>
        </form>
      </div>
    </div>
  );
}
