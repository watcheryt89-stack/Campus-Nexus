import { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase, Timetable } from '../../lib/supabase';
import { Calendar, Clock, MapPin, User, Plus, BookOpen, Target, Brain } from 'lucide-react';

export default function AcademicCockpit() {
  const { profile } = useAuth();
  const [timetable, setTimetable] = useState<Timetable[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [currentDay, setCurrentDay] = useState(new Date().getDay());

  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  useEffect(() => {
    loadTimetable();
  }, []);

  async function loadTimetable() {
    setLoading(true);
    try {
      const { data } = await supabase
        .from('timetables')
        .select('*')
        .eq('user_id', profile?.id)
        .order('day_of_week')
        .order('start_time');
      setTimetable(data || []);
    } catch (error) {
      console.error('Error loading timetable:', error);
    } finally {
      setLoading(false);
    }
  }

  const getTodayClasses = () => {
    return timetable.filter(item => item.day_of_week === currentDay);
  };

  const getUpcomingClass = () => {
    const todayClasses = getTodayClasses();
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();

    return todayClasses.find(item => {
      const [hours, minutes] = item.start_time.split(':').map(Number);
      const classTime = hours * 60 + minutes;
      return classTime > currentTime;
    });
  };

  const upcomingClass = getUpcomingClass();

  const getAIRecommendations = () => {
    const recommendations = [
      {
        icon: Brain,
        title: 'Study Recommendation',
        description: 'Based on your schedule, focus on Data Structures today',
        color: 'text-blue-500',
      },
      {
        icon: Target,
        title: 'Upcoming Deadline',
        description: 'Machine Learning assignment due in 3 days',
        color: 'text-red-500',
      },
      {
        icon: BookOpen,
        title: 'Study Group Available',
        description: '5 students studying Algorithms in Library at 6 PM',
        color: 'text-green-500',
      },
    ];
    return recommendations;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Academic Cockpit</h2>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Class
        </button>
      </div>

      {upcomingClass && (
        <div className="bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl p-6 text-white">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5" />
            <span className="text-sm font-medium">Next Class</span>
          </div>
          <h3 className="text-2xl font-bold mb-2">{upcomingClass.course_name}</h3>
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>{upcomingClass.start_time} - {upcomingClass.end_time}</span>
            </div>
            {upcomingClass.room && (
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>{upcomingClass.room}</span>
              </div>
            )}
            {upcomingClass.instructor && (
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                <span>{upcomingClass.instructor}</span>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {getAIRecommendations().map((rec, idx) => (
          <div key={idx} className="border border-gray-200 dark:border-gray-700 rounded-xl p-4">
            <rec.icon className={`w-8 h-8 mb-3 ${rec.color}`} />
            <h4 className="font-semibold text-gray-900 dark:text-white mb-1">{rec.title}</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">{rec.description}</p>
          </div>
        ))}
      </div>

      <div>
        <div className="flex gap-2 mb-4 overflow-x-auto">
          {days.map((day, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentDay(idx)}
              className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
                currentDay === idx
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              {day}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <div className="space-y-3">
            {getTodayClasses().length === 0 ? (
              <div className="text-center py-12 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-xl">
                <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-400">No classes scheduled for {days[currentDay]}</p>
              </div>
            ) : (
              getTodayClasses().map((item) => (
                <div
                  key={item.id}
                  className="border border-gray-200 dark:border-gray-700 rounded-xl p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="font-semibold text-gray-900 dark:text-white">{item.course_name}</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{item.course_code}</p>
                    </div>
                    <span className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full text-sm font-medium">
                      {item.start_time} - {item.end_time}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-400">
                    {item.room && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        <span>{item.room}</span>
                      </div>
                    )}
                    {item.instructor && (
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        <span>{item.instructor}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {showAddModal && (
        <AddClassModal
          onClose={() => setShowAddModal(false)}
          onSuccess={() => {
            setShowAddModal(false);
            loadTimetable();
          }}
          userId={profile?.id || ''}
        />
      )}
    </div>
  );
}

function AddClassModal({
  onClose,
  onSuccess,
  userId,
}: {
  onClose: () => void;
  onSuccess: () => void;
  userId: string;
}) {
  const [formData, setFormData] = useState<any>({});
  const [loading, setLoading] = useState(false);

  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    try {
      await supabase.from('timetables').insert({
        user_id: userId,
        course_code: formData.course_code,
        course_name: formData.course_name,
        day_of_week: parseInt(formData.day_of_week),
        start_time: formData.start_time,
        end_time: formData.end_time,
        room: formData.room,
        instructor: formData.instructor,
      });
      onSuccess();
    } catch (error) {
      console.error('Error adding class:', error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 max-w-md w-full">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Add Class</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Course code (e.g., CS101)"
            onChange={(e) => setFormData({ ...formData, course_code: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
            required
          />
          <input
            type="text"
            placeholder="Course name"
            onChange={(e) => setFormData({ ...formData, course_name: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
            required
          />
          <select
            onChange={(e) => setFormData({ ...formData, day_of_week: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
            required
          >
            <option value="">Select day</option>
            {days.map((day, idx) => (
              <option key={idx} value={idx}>{day}</option>
            ))}
          </select>
          <div className="grid grid-cols-2 gap-3">
            <input
              type="time"
              placeholder="Start time"
              onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
              required
            />
            <input
              type="time"
              placeholder="End time"
              onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
              required
            />
          </div>
          <input
            type="text"
            placeholder="Room (optional)"
            onChange={(e) => setFormData({ ...formData, room: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          />
          <input
            type="text"
            placeholder="Instructor (optional)"
            onChange={(e) => setFormData({ ...formData, instructor: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          />
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 rounded-lg transition-colors disabled:opacity-50"
            >
              {loading ? 'Adding...' : 'Add Class'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
