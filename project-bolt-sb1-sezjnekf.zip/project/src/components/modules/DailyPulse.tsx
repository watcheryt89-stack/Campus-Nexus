import { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase, MessMenuItem, CampusEmail, Announcement } from '../../lib/supabase';
import {
  UtensilsCrossed, Mail, Megaphone, TrendingUp, AlertTriangle,
  Calendar, Users, Sparkles, Eye, EyeOff
} from 'lucide-react';

export default function DailyPulse() {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'menu' | 'emails' | 'announcements'>('menu');
  const [messMenu, setMessMenu] = useState<MessMenuItem[]>([]);
  const [emails, setEmails] = useState<CampusEmail[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [newEmail, setNewEmail] = useState({ subject: '', content: '' });
  const [summarizing, setSummarizing] = useState(false);

  useEffect(() => {
    loadData();
  }, [activeTab]);

  async function loadData() {
    setLoading(true);
    try {
      if (activeTab === 'menu') {
        const today = new Date().toISOString().split('T')[0];
        const { data } = await supabase
          .from('mess_menu')
          .select('*')
          .eq('date', today)
          .order('meal_type');
        setMessMenu(data || []);
      } else if (activeTab === 'emails') {
        const { data } = await supabase
          .from('campus_emails')
          .select('*')
          .eq('user_id', profile?.id)
          .order('received_at', { ascending: false })
          .limit(10);
        setEmails(data || []);
      } else if (activeTab === 'announcements') {
        const { data } = await supabase
          .from('announcements')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(10);
        setAnnouncements(data || []);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleEmailSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!newEmail.subject || !newEmail.content) return;

    setSummarizing(true);
    try {
      const aiSummary = await generateAISummary(newEmail.content);
      const category = categorizeEmail(newEmail.subject, newEmail.content);
      const priorityScore = calculatePriority(newEmail.subject, newEmail.content);
      const deadlines = extractDeadlines(newEmail.content);

      const { error } = await supabase.from('campus_emails').insert({
        user_id: profile?.id,
        subject: newEmail.subject,
        original_content: newEmail.content,
        ai_summary: aiSummary,
        category,
        priority_score: priorityScore,
        deadlines,
        is_read: false,
      });

      if (!error) {
        setNewEmail({ subject: '', content: '' });
        loadData();
      }
    } catch (error) {
      console.error('Error processing email:', error);
    } finally {
      setSummarizing(false);
    }
  }

  async function generateAISummary(content: string): Promise<string> {
    const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 10);
    const keywords = extractKeywords(content);
    const firstSentence = sentences[0]?.trim() || '';

    if (keywords.length > 0) {
      return `${firstSentence.substring(0, 100)}... Key points: ${keywords.slice(0, 3).join(', ')}`;
    }

    return firstSentence.substring(0, 150) + '...';
  }

  function extractKeywords(text: string): string[] {
    const stopWords = ['the', 'is', 'at', 'which', 'on', 'a', 'an', 'and', 'or', 'but'];
    const words = text.toLowerCase().match(/\b\w+\b/g) || [];
    const wordFreq: Record<string, number> = {};

    words.forEach(word => {
      if (word.length > 4 && !stopWords.includes(word)) {
        wordFreq[word] = (wordFreq[word] || 0) + 1;
      }
    });

    return Object.entries(wordFreq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([word]) => word);
  }

  function categorizeEmail(subject: string, content: string): 'academic' | 'events' | 'urgent' | 'general' {
    const text = (subject + ' ' + content).toLowerCase();

    if (text.includes('exam') || text.includes('assignment') || text.includes('grade') || text.includes('course')) {
      return 'academic';
    }
    if (text.includes('urgent') || text.includes('important') || text.includes('asap') || text.includes('deadline')) {
      return 'urgent';
    }
    if (text.includes('event') || text.includes('workshop') || text.includes('seminar') || text.includes('fest')) {
      return 'events';
    }
    return 'general';
  }

  function calculatePriority(subject: string, content: string): number {
    const text = (subject + ' ' + content).toLowerCase();
    let score = 3;

    if (text.includes('urgent') || text.includes('important')) score += 2;
    if (text.includes('deadline') || text.includes('due date')) score += 1;
    if (text.includes('exam') || text.includes('test')) score += 1;

    return Math.min(score, 5);
  }

  function extractDeadlines(content: string): any[] {
    const datePatterns = [
      /(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/g,
      /(\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{2,4})/gi
    ];

    const deadlines: any[] = [];
    datePatterns.forEach(pattern => {
      const matches = content.match(pattern);
      if (matches) {
        matches.forEach(match => {
          deadlines.push({ date: match, context: 'Found in email' });
        });
      }
    });

    return deadlines;
  }

  async function toggleReadStatus(emailId: string, currentStatus: boolean) {
    await supabase
      .from('campus_emails')
      .update({ is_read: !currentStatus })
      .eq('id', emailId);
    loadData();
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'academic': return 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300';
      case 'events': return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300';
      case 'urgent': return 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Daily Pulse</h2>
        <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
          <Calendar className="w-4 h-4" />
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </div>
      </div>

      <div className="flex gap-2 border-b border-gray-200 dark:border-gray-700">
        <button
          onClick={() => setActiveTab('menu')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'menu'
              ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          <div className="flex items-center gap-2">
            <UtensilsCrossed className="w-4 h-4" />
            Mess Menu
          </div>
        </button>
        <button
          onClick={() => setActiveTab('emails')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'emails'
              ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4" />
            AI Mail Summarizer
            {emails.filter(e => !e.is_read).length > 0 && (
              <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                {emails.filter(e => !e.is_read).length}
              </span>
            )}
          </div>
        </button>
        <button
          onClick={() => setActiveTab('announcements')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'announcements'
              ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          <div className="flex items-center gap-2">
            <Megaphone className="w-4 h-4" />
            Announcements
          </div>
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <>
          {activeTab === 'menu' && (
            <div className="space-y-4">
              {messMenu.length === 0 ? (
                <div className="text-center py-12">
                  <UtensilsCrossed className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">No menu available for today</p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">Check back later</p>
                </div>
              ) : (
                messMenu.map((menu) => (
                  <div key={menu.id} className="border border-gray-200 dark:border-gray-700 rounded-xl p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white capitalize">
                        {menu.meal_type}
                      </h3>
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-gray-500" />
                        <div className="flex gap-1">
                          {[...Array(5)].map((_, i) => (
                            <div
                              key={i}
                              className={`w-2 h-4 rounded ${
                                i < menu.crowd_prediction ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {Array.isArray(menu.items) && menu.items.map((item: any, idx: number) => (
                        <span
                          key={idx}
                          className="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-full text-sm"
                        >
                          {typeof item === 'string' ? item : item.name}
                        </span>
                      ))}
                    </div>
                    {menu.allergens.length > 0 && (
                      <div className="flex items-start gap-2 text-sm text-orange-600 dark:text-orange-400">
                        <AlertTriangle className="w-4 h-4 mt-0.5" />
                        <span>Contains: {menu.allergens.join(', ')}</span>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'emails' && (
            <div className="space-y-4">
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  <h3 className="font-semibold text-gray-900 dark:text-white">Add New Email</h3>
                </div>
                <form onSubmit={handleEmailSubmit} className="space-y-3">
                  <input
                    type="text"
                    placeholder="Email subject"
                    value={newEmail.subject}
                    onChange={(e) => setNewEmail({ ...newEmail, subject: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                    required
                  />
                  <textarea
                    placeholder="Paste your long email content here..."
                    value={newEmail.content}
                    onChange={(e) => setNewEmail({ ...newEmail, content: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white h-32 resize-none"
                    required
                  />
                  <button
                    type="submit"
                    disabled={summarizing}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition-colors disabled:opacity-50"
                  >
                    {summarizing ? 'Summarizing with AI...' : 'Summarize with AI'}
                  </button>
                </form>
              </div>

              {emails.map((email) => (
                <div
                  key={email.id}
                  className={`border rounded-xl p-4 ${
                    email.is_read
                      ? 'border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50'
                      : 'border-blue-200 dark:border-blue-800 bg-white dark:bg-gray-800'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-gray-900 dark:text-white">{email.subject}</h4>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${getCategoryColor(email.category)}`}>
                          {email.category}
                        </span>
                        <div className="flex gap-0.5">
                          {[...Array(email.priority_score)].map((_, i) => (
                            <TrendingUp key={i} className="w-3 h-3 text-red-500" />
                          ))}
                        </div>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                        {new Date(email.received_at).toLocaleString()}
                      </p>
                    </div>
                    <button
                      onClick={() => toggleReadStatus(email.id, email.is_read)}
                      className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                    >
                      {email.is_read ? (
                        <Eye className="w-4 h-4 text-gray-400" />
                      ) : (
                        <EyeOff className="w-4 h-4 text-blue-500" />
                      )}
                    </button>
                  </div>
                  <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3 mb-2">
                    <div className="flex items-start gap-2">
                      <Sparkles className="w-4 h-4 text-yellow-600 dark:text-yellow-400 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-gray-900 dark:text-white mb-1">AI Summary</p>
                        <p className="text-sm text-gray-700 dark:text-gray-300">{email.ai_summary}</p>
                      </div>
                    </div>
                  </div>
                  {email.deadlines.length > 0 && (
                    <div className="flex items-center gap-2 text-sm text-red-600 dark:text-red-400">
                      <AlertTriangle className="w-4 h-4" />
                      <span>Deadlines found: {email.deadlines.length}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {activeTab === 'announcements' && (
            <div className="space-y-4">
              {announcements.length === 0 ? (
                <div className="text-center py-12">
                  <Megaphone className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">No announcements yet</p>
                </div>
              ) : (
                announcements.map((announcement) => (
                  <div key={announcement.id} className="border border-gray-200 dark:border-gray-700 rounded-xl p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-gray-900 dark:text-white">{announcement.title}</h4>
                      <div className="flex gap-0.5">
                        {[...Array(announcement.priority)].map((_, i) => (
                          <div key={i} className="w-2 h-2 rounded-full bg-red-500" />
                        ))}
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{announcement.content}</p>
                    <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-500">
                      <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded">{announcement.category}</span>
                      <span>{new Date(announcement.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
