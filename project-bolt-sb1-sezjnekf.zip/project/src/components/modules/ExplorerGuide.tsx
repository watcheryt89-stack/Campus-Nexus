import { useState } from 'react';
import { Map, Coffee, BookOpen, Utensils, Star, MapPin, Clock, DollarSign, TrendingUp } from 'lucide-react';

export default function ExplorerGuide() {
  const [activeTab, setActiveTab] = useState<'nearby' | 'campus'>('nearby');
  const [selectedFilter, setSelectedFilter] = useState<string>('all');

  const nearbyPlaces = [
    {
      id: 1,
      name: 'Campus Cafe',
      type: 'cafe',
      distance: '0.2 km',
      rating: 4.5,
      reviews: 124,
      vibe: ['study', 'wifi', 'quiet'],
      price: '$$',
      hours: '7 AM - 11 PM',
      description: 'Perfect spot for studying with great coffee and fast wifi',
    },
    {
      id: 2,
      name: 'Book Haven',
      type: 'bookstore',
      distance: '0.5 km',
      rating: 4.8,
      reviews: 89,
      vibe: ['books', 'quiet', 'academic'],
      price: '$$$',
      hours: '9 AM - 9 PM',
      description: 'Academic books and stationery at student-friendly prices',
    },
    {
      id: 3,
      name: 'Street Food Corner',
      type: 'food',
      distance: '0.3 km',
      rating: 4.2,
      reviews: 256,
      vibe: ['budget', 'quick', 'hangout'],
      price: '$',
      hours: '11 AM - 10 PM',
      description: 'Affordable and delicious street food favorites',
    },
    {
      id: 4,
      name: 'Tech Hub',
      type: 'electronics',
      distance: '0.8 km',
      rating: 4.6,
      reviews: 67,
      vibe: ['tech', 'reliable'],
      price: '$$',
      hours: '10 AM - 8 PM',
      description: 'Electronics and gadgets with student discounts',
    },
  ];

  const campusLocations = [
    {
      id: 1,
      name: 'Central Library',
      building: 'Building A',
      floor: '1-4',
      type: 'library',
      facilities: ['Study rooms', 'Computer lab', 'Printer', 'Cafeteria'],
      hours: '24/7',
    },
    {
      id: 2,
      name: 'Computer Science Block',
      building: 'Building C',
      floor: '1-3',
      type: 'academic',
      facilities: ['Labs', 'Lecture halls', 'Project rooms'],
      hours: '8 AM - 10 PM',
    },
    {
      id: 3,
      name: 'Sports Complex',
      building: 'Building S',
      floor: 'Ground',
      type: 'sports',
      facilities: ['Gym', 'Basketball court', 'Swimming pool'],
      hours: '6 AM - 10 PM',
    },
  ];

  const filters = ['all', 'study', 'food', 'budget', 'hangout'];

  const filteredPlaces = selectedFilter === 'all'
    ? nearbyPlaces
    : nearbyPlaces.filter(place => place.vibe.includes(selectedFilter));

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'cafe': return Coffee;
      case 'bookstore': return BookOpen;
      case 'food': return Utensils;
      default: return MapPin;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Explorer's Guide</h2>
        <Map className="w-6 h-6 text-blue-600 dark:text-blue-400" />
      </div>

      <div className="flex gap-2 border-b border-gray-200 dark:border-gray-700">
        <button
          onClick={() => setActiveTab('nearby')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'nearby'
              ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          Nearby Hub
        </button>
        <button
          onClick={() => setActiveTab('campus')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'campus'
              ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          Campus Map
        </button>
      </div>

      {activeTab === 'nearby' && (
        <>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {filters.map((filter) => (
              <button
                key={filter}
                onClick={() => setSelectedFilter(filter)}
                className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
                  selectedFilter === filter
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {filter.charAt(0).toUpperCase() + filter.slice(1)}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredPlaces.map((place) => {
              const Icon = getTypeIcon(place.type);
              return (
                <div
                  key={place.id}
                  className="border border-gray-200 dark:border-gray-700 rounded-xl p-4 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                        <Icon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-white">{place.name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-yellow-500 fill-current" />
                            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                              {place.rating}
                            </span>
                          </div>
                          <span className="text-sm text-gray-500">({place.reviews})</span>
                        </div>
                      </div>
                    </div>
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-400">{place.price}</span>
                  </div>

                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{place.description}</p>

                  <div className="flex flex-wrap gap-2 mb-3">
                    {place.vibe.map((tag, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded text-xs"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span>{place.distance}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span>{place.hours}</span>
                    </div>
                  </div>

                  <button className="w-full mt-3 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition-colors">
                    Get Directions
                  </button>
                </div>
              );
            })}
          </div>

          <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl p-6 text-white">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5" />
              <span className="font-semibold">AI Recommendation</span>
            </div>
            <h4 className="text-xl font-bold mb-2">Campus Cafe is trending today</h4>
            <p className="text-sm opacity-90">
              Popular among students for group study sessions. Less crowded after 3 PM.
            </p>
          </div>
        </>
      )}

      {activeTab === 'campus' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-br from-blue-100 to-cyan-100 dark:from-blue-900/20 dark:to-cyan-900/20 rounded-xl p-8 border border-blue-200 dark:border-blue-800">
            <div className="text-center">
              <Map className="w-16 h-16 text-blue-600 dark:text-blue-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Interactive Campus Map</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Navigate the campus with ease using our AI-powered map
              </p>
              <button className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors">
                Open Full Map
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {campusLocations.map((location) => (
              <div
                key={location.id}
                className="border border-gray-200 dark:border-gray-700 rounded-xl p-4"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">{location.name}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {location.building} • Floor {location.floor}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                    <Clock className="w-4 h-4" />
                    <span>{location.hours}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-3">
                  {location.facilities.map((facility, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full text-sm"
                    >
                      {facility}
                    </span>
                  ))}
                </div>

                <button className="w-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 font-medium py-2 rounded-lg transition-colors">
                  View on Map
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
