import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import {
  Zap, ShoppingBag, Map, Calendar, LogOut, Moon, Sun,
  Menu, X, User
} from 'lucide-react';
import DailyPulse from './modules/DailyPulse';
import StudentExchange from './modules/StudentExchange';
import AcademicCockpit from './modules/AcademicCockpit';
import ExplorerGuide from './modules/ExplorerGuide';

type Module = 'pulse' | 'exchange' | 'explorer' | 'academic';

export default function Dashboard() {
  const { profile, signOut } = useAuth();
  const [activeModule, setActiveModule] = useState<Module>('pulse');
  const [darkMode, setDarkMode] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  const modules = [
    { id: 'pulse' as Module, name: 'Daily Pulse', icon: Zap, color: 'text-yellow-500' },
    { id: 'exchange' as Module, name: 'Student Exchange', icon: ShoppingBag, color: 'text-green-500' },
    { id: 'explorer' as Module, name: "Explorer's Guide", icon: Map, color: 'text-blue-500' },
    { id: 'academic' as Module, name: 'Academic Cockpit', icon: Calendar, color: 'text-red-500' },
  ];

  const renderModule = () => {
    switch (activeModule) {
      case 'pulse':
        return <DailyPulse />;
      case 'exchange':
        return <StudentExchange />;
      case 'explorer':
        return <ExplorerGuide />;
      case 'academic':
        return <AcademicCockpit />;
      default:
        return <DailyPulse />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <nav className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-xl">N</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                  Project Nexus
                </h1>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  AI-Powered Campus Hub
                </p>
              </div>
            </div>

            <div className="hidden md:flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg">
                <User className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {profile?.full_name}
                </span>
                <span className="text-xs px-2 py-0.5 bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 rounded-full">
                  {profile?.role}
                </span>
              </div>

              <button
                onClick={toggleDarkMode}
                className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>

              <button
                onClick={signOut}
                className="flex items-center gap-2 px-4 py-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm font-medium">Logout</span>
              </button>
            </div>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-gray-600 dark:text-gray-400"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
            <div className="px-4 py-3 space-y-2">
              <div className="flex items-center gap-2 px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg">
                <User className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {profile?.full_name}
                </span>
              </div>
              <button
                onClick={toggleDarkMode}
                className="w-full flex items-center gap-2 px-3 py-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
              >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                <span>Toggle Theme</span>
              </button>
              <button
                onClick={signOut}
                className="w-full flex items-center gap-2 px-3 py-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        )}
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {modules.map((module) => (
            <button
              key={module.id}
              onClick={() => setActiveModule(module.id)}
              className={`p-4 rounded-xl border-2 transition-all ${
                activeModule === module.id
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                  : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-gray-300 dark:hover:border-gray-600'
              }`}
            >
              <module.icon className={`w-8 h-8 mb-2 mx-auto ${module.color}`} />
              <p className={`text-sm font-medium ${
                activeModule === module.id
                  ? 'text-blue-600 dark:text-blue-400'
                  : 'text-gray-700 dark:text-gray-300'
              }`}>
                {module.name}
              </p>
            </button>
          ))}
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 min-h-[600px]">
          {renderModule()}
        </div>
      </div>
    </div>
  );
}
